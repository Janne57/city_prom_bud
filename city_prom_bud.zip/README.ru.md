Этот проект был создан Евгенией Пащенко (evgeniyahome1981@gmail.com)при помощи Vite (https://vitejs.dev/).
